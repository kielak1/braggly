ALTER TABLE cod_entry
    ALTER COLUMN cod_id TYPE varchar(355),
    ALTER COLUMN mineral_name TYPE varchar(356),
    ALTER COLUMN formula TYPE varchar(357),
    ALTER COLUMN elements TYPE varchar(358),
    ALTER COLUMN publication_year TYPE varchar(359),
    ALTER COLUMN authors TYPE varchar(360),
    ALTER COLUMN journal TYPE varchar(361),
    ALTER COLUMN doi TYPE varchar(363),
    ALTER COLUMN download_url TYPE varchar(363);
