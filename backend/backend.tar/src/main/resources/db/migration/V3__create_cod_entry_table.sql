ALTER TABLE cod_entry
    ALTER COLUMN authors TYPE varchar(2048);
